<?php
// database constants for MySQL
define("DB_SERVER", "localhost");
define("DB_USER", "root");
define("DB_PASS", "root");
define("DB_NAME", "buildmeister");
// site constants
define("SITE_BASEDIR", "@site_basedir@");
?>
